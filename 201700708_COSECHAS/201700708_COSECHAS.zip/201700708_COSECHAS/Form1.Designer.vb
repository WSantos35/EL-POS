﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class xx
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnInicializar = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtNit = New System.Windows.Forms.TextBox()
        Me.txtTipoCosecha = New System.Windows.Forms.TextBox()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.txtPrecioCafe = New System.Windows.Forms.TextBox()
        Me.txtPrecioAzucar = New System.Windows.Forms.TextBox()
        Me.txtPrecioBanano = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPrecioCardamomo = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtTotalParcial = New System.Windows.Forms.TextBox()
        Me.txtPagoTransporte = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtPagoExtra = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCantBanano = New System.Windows.Forms.TextBox()
        Me.txtCantCardamomo = New System.Windows.Forms.TextBox()
        Me.txtCantAzucar = New System.Windows.Forms.TextBox()
        Me.txtCantCafe = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.SuspendLayout()
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Location = New System.Drawing.Point(652, 450)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(94, 29)
        Me.btnLimpiar.TabIndex = 0
        Me.btnLimpiar.Text = "LIMPIAR"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'btnInicializar
        '
        Me.btnInicializar.Location = New System.Drawing.Point(507, 450)
        Me.btnInicializar.Name = "btnInicializar"
        Me.btnInicializar.Size = New System.Drawing.Size(103, 29)
        Me.btnInicializar.TabIndex = 1
        Me.btnInicializar.Text = "CALCULAR"
        Me.btnInicializar.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(777, 450)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(94, 29)
        Me.btnSalir.TabIndex = 2
        Me.btnSalir.Text = "SALIR"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(54, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nit"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(54, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Nombre del Cliente"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(54, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Tipo de Cosecha"
        '
        'txtNit
        '
        Me.txtNit.Location = New System.Drawing.Point(230, 38)
        Me.txtNit.Name = "txtNit"
        Me.txtNit.Size = New System.Drawing.Size(130, 27)
        Me.txtNit.TabIndex = 6
        '
        'txtTipoCosecha
        '
        Me.txtTipoCosecha.Location = New System.Drawing.Point(230, 107)
        Me.txtTipoCosecha.Name = "txtTipoCosecha"
        Me.txtTipoCosecha.Size = New System.Drawing.Size(130, 27)
        Me.txtTipoCosecha.TabIndex = 7
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(230, 74)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(130, 27)
        Me.txtNombre.TabIndex = 8
        '
        'txtPrecioCafe
        '
        Me.txtPrecioCafe.Location = New System.Drawing.Point(230, 205)
        Me.txtPrecioCafe.Name = "txtPrecioCafe"
        Me.txtPrecioCafe.Size = New System.Drawing.Size(130, 27)
        Me.txtPrecioCafe.TabIndex = 14
        Me.txtPrecioCafe.Text = "125.15"
        '
        'txtPrecioAzucar
        '
        Me.txtPrecioAzucar.Location = New System.Drawing.Point(230, 238)
        Me.txtPrecioAzucar.Name = "txtPrecioAzucar"
        Me.txtPrecioAzucar.Size = New System.Drawing.Size(130, 27)
        Me.txtPrecioAzucar.TabIndex = 13
        Me.txtPrecioAzucar.Text = "110.50"
        '
        'txtPrecioBanano
        '
        Me.txtPrecioBanano.Location = New System.Drawing.Point(230, 169)
        Me.txtPrecioBanano.Name = "txtPrecioBanano"
        Me.txtPrecioBanano.Size = New System.Drawing.Size(130, 27)
        Me.txtPrecioBanano.TabIndex = 12
        Me.txtPrecioBanano.Text = "110.00"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(54, 245)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(118, 20)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Precio de azúcar"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(54, 212)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 20)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Precio del café"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(54, 172)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(129, 20)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Precio del Banano"
        '
        'txtPrecioCardamomo
        '
        Me.txtPrecioCardamomo.Location = New System.Drawing.Point(230, 271)
        Me.txtPrecioCardamomo.Name = "txtPrecioCardamomo"
        Me.txtPrecioCardamomo.Size = New System.Drawing.Size(130, 27)
        Me.txtPrecioCardamomo.TabIndex = 16
        Me.txtPrecioCardamomo.Text = "120.99"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(54, 278)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(158, 20)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Precio de Cardamomo"
        '
        'txtTotalParcial
        '
        Me.txtTotalParcial.Location = New System.Drawing.Point(510, 277)
        Me.txtTotalParcial.Name = "txtTotalParcial"
        Me.txtTotalParcial.Size = New System.Drawing.Size(153, 27)
        Me.txtTotalParcial.TabIndex = 17
        '
        'txtPagoTransporte
        '
        Me.txtPagoTransporte.Location = New System.Drawing.Point(510, 343)
        Me.txtPagoTransporte.Name = "txtPagoTransporte"
        Me.txtPagoTransporte.Size = New System.Drawing.Size(153, 27)
        Me.txtPagoTransporte.TabIndex = 18
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(755, 343)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(153, 27)
        Me.txtTotal.TabIndex = 19
        '
        'txtPagoExtra
        '
        Me.txtPagoExtra.Location = New System.Drawing.Point(755, 270)
        Me.txtPagoExtra.Name = "txtPagoExtra"
        Me.txtPagoExtra.Size = New System.Drawing.Size(153, 27)
        Me.txtPagoExtra.TabIndex = 20
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(510, 239)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 20)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Total Parcial"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(751, 235)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 20)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Pago Extra"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(510, 317)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 20)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Pago Trasnporte"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(755, 320)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(42, 20)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Total"
        '
        'txtCantBanano
        '
        Me.txtCantBanano.Location = New System.Drawing.Point(54, 403)
        Me.txtCantBanano.Name = "txtCantBanano"
        Me.txtCantBanano.Size = New System.Drawing.Size(153, 27)
        Me.txtCantBanano.TabIndex = 25
        '
        'txtCantCardamomo
        '
        Me.txtCantCardamomo.Location = New System.Drawing.Point(248, 450)
        Me.txtCantCardamomo.Name = "txtCantCardamomo"
        Me.txtCantCardamomo.Size = New System.Drawing.Size(153, 27)
        Me.txtCantCardamomo.TabIndex = 26
        '
        'txtCantAzucar
        '
        Me.txtCantAzucar.Location = New System.Drawing.Point(54, 450)
        Me.txtCantAzucar.Name = "txtCantAzucar"
        Me.txtCantAzucar.Size = New System.Drawing.Size(153, 27)
        Me.txtCantAzucar.TabIndex = 27
        '
        'txtCantCafe
        '
        Me.txtCantCafe.Location = New System.Drawing.Point(248, 403)
        Me.txtCantCafe.Name = "txtCantCafe"
        Me.txtCantCafe.Size = New System.Drawing.Size(153, 27)
        Me.txtCantCafe.TabIndex = 28
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(187, 350)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(155, 20)
        Me.Label12.TabIndex = 29
        Me.Label12.Text = "Cantidad en Quintales"
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"Banano", "Café", "Azúcar", "Cardamomo"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(507, 61)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(171, 92)
        Me.CheckedListBox1.TabIndex = 30
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Items.AddRange(New Object() {"Bodega Sur", "Bodega Occidente", "Bodega Norte", "Bodega Oriente"})
        Me.CheckedListBox2.Location = New System.Drawing.Point(737, 61)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(171, 92)
        Me.CheckedListBox2.TabIndex = 31
        '
        'xx
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1059, 559)
        Me.Controls.Add(Me.CheckedListBox2)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtCantCafe)
        Me.Controls.Add(Me.txtCantAzucar)
        Me.Controls.Add(Me.txtCantCardamomo)
        Me.Controls.Add(Me.txtCantBanano)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtPagoExtra)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtPagoTransporte)
        Me.Controls.Add(Me.txtTotalParcial)
        Me.Controls.Add(Me.txtPrecioCardamomo)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtPrecioCafe)
        Me.Controls.Add(Me.txtPrecioAzucar)
        Me.Controls.Add(Me.txtPrecioBanano)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtNombre)
        Me.Controls.Add(Me.txtTipoCosecha)
        Me.Controls.Add(Me.txtNit)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnInicializar)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Name = "xx"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnInicializar As Button
    Friend WithEvents btnSalir As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtNit As TextBox
    Friend WithEvents txtTipoCosecha As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtPrecioCafe As TextBox
    Friend WithEvents txtPrecioAzucar As TextBox
    Friend WithEvents txtPrecioBanano As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtPrecioCardamomo As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtTotalParcial As TextBox
    Friend WithEvents txtPagoTransporte As TextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtPagoExtra As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtCantBanano As TextBox
    Friend WithEvents txtCantCardamomo As TextBox
    Friend WithEvents txtCantAzucar As TextBox
    Friend WithEvents txtCantCafe As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
End Class
